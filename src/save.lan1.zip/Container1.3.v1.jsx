import React, { Component } from "react";
import Counter from "./Counter";
import "./Container1.css";

class Container1 extends Component {
  constructor(props) {
    super(props);
    this.state = {
      counters: [
        { id: 0, value: 2, role: 1 },
        { id: 1, value: 5, role: 0 },
        { id: 2, value: 2, role: 0 },
      ],
    };
  }
  onClickCounter = (id, isUp, role) => {
    if (role === 0) {
      const newCounters = this.state.counters.map((item) => {
        const newItem = { ...item };
        if (newItem.id === id) {
          if (isUp) newItem.value += 1;
          else if (newItem.value !== 0) newItem.value -= 1;
        }
        return newItem;
      });
      this.setState({ counters: newCounters });
    } else {
      const newCounters = [...this.state.counters];
      const firstItem = newCounters[0];
      if (isUp) {
        firstItem.value += 1;
        const a = this.state.counters.length;
        newCounters.push({ id: a, value: 1, role: 0 });
      } else if (firstItem.value !== 0) {
        firstItem.value -= 1;
        newCounters.pop();
      }
      this.setState({ counters: newCounters });
    }
  }
  onChangeCounter = (id, role, sNum) => {
    // console.log(`id: ${id}role: ${role} sNum: ${sNum}`);
    const newCounters = this.state.counters.map((item) => {
      const newItem = { ...item };
      if (newItem.id === id) {
        const a = Number.parseInt(sNum, 10);
        newItem.value = Number.isNaN(a) ? 0 : a;
      }
      return newItem;
    });
    // this.setState({ counters: newCounters });
    // console.log(`counters : ${this.state.counters}`);
    if (role === 1) {
      let a = this.state.counters.length - 1; // so Counter con
      const b = newCounters[0].value - a;
      console.log(`b: ${b}`);
      console.log(`state length: ${a}`);
      console.log(`copy length: ${newCounters.length}`);
      if (b > 0) {
        for (let i = 0; i < b; i += 1) {
          newCounters.push({ id: a, value: 1, role: 0 });
          a += 1;
        }
      } else {
        for (let i = b; i < 0; i += 1) {
          newCounters.pop();
        }
      }
    }
    console.log(`state length: ${this.state.counters.length}`);
    console.log(`copy length: ${newCounters.length}`);
    this.setState({ counters: newCounters });
  }
  render() {
    return (
      <div>
        {this.state.counters.map(item => (
          <Counter
            key={item.id}
            id={item.id}
            role={item.role}
            value={item.value}
            onClickCounter={this.onClickCounter}
            onChangeCounter={this.onChangeCounter}
          />
        ))}
      </div>
    );
  }
}
export default Container1;

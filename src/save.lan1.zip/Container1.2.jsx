import React, { Component } from "react";
import Counter from "./Counter";

class Container1 extends Component {
  constructor(props) {
    super(props);
    this.state = {
      counters: [
        { id: 0, value: 2, role: 1 },
        { id: 1, value: 5, role: 0 },
        { id: 2, value: 2, role: 0 },
      ],
    };
  }

  onClickCounter = (id, isUp, role) => {
    if (role === 0) {
      const newCounters = this.state.counters.map((item) => {
        const newItem = { ...item };
        if (newItem.id === id) {
          if (isUp) newItem.value += 1;
          else newItem.value -= 1;
        }
        return newItem;
      });
      this.setState({ counters: newCounters });
    } else {
      // const newCounters = this.state.counters.map((item) => {
      //   const newItem = { ...item };
      //   if (newItem.id === id) {
      //     if (isUp) {
      //       newItem.value += 1;
      //       const a = this.state.counters.length - 1;
      //       const b = this.state.counters[a].id + 1;
      //       this.state.counters.push({ id: b, value: 1, role: 0 });
      //     } else {
      //       newItem.value -= 1;
      //       this.state.counters.pop();
      //     }
      //   }
      //   return newItem;
      // });
      const newCounters = [...this.state.counters];
      const firstItem = newCounters[0];
      console.log(newCounters);
      if (isUp) {
        firstItem.value += 1;
        const a = this.state.counters.length;
        newCounters.push({ id: a, value: 1, role: 0 });
      } else if (firstItem.value === 0) {
        firstItem.value += 0;
      } else {
        firstItem.value -= 1;
        newCounters.pop();
      }
      this.setState({ counters: newCounters });
    }
  }

  onChangeCounter = (id, role) => {
    if (role === 0) {
      const newCounters = this.state.counters.map((item) => {
        const newItem = { ...item };
        if (newItem.id === id) {
          // newItem.value = Number.parseInt(refs.valueref.value);
        }
        return newItem;
      });
      this.setState({ counters: newCounters });
    }
  }

  render() {
    return (
      <div>
        {this.state.counters.map(item => (
          <Counter
            key={item.id}
            id={item.id}
            role={item.role}
            value={item.value}
            onClickCounter={this.onClickCounter}
          />
        ))}
      </div>
    );
  }
}

// const Container1 = (numCounter) => {
//   const rows = [];
//   for (let i = 0; i < numCounter; i += 1) {
//     rows.push(<Counter />);
//   }
//   return (
//     <tbody>{rows}</tbody>
//   );
// };

export default Container1;

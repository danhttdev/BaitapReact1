import React, { Component } from "react";
import Counter from "./Counter";

class Container1 extends Component {
  constructor(props) {
    super(props);
    this.state = {
      counters: [
        // { id: 0, value: 5, role: 1 },
        { id: 1, value: 5, role: 0 },
        { id: 2, value: 2, role: 0 },
      ],
    };
  }

  onClickCounter = (id, isUp, role) => {
    if (role === 1) {
      this.state.counters.push({ id: null, value: 1, role: 0 });
    }
    const newCounters = this.state.counters.map((item) => {
      const newItem = { ...item };
      if (newItem.id === id) {
        if (isUp) newItem.value += 1;
        else newItem.value -= 1;
      }
      return newItem;
    });
    this.setState({
      counters: newCounters,
    });
  }
  // if (role === 0) {
  //   const newCounters = this.state.counters.map((item) => {
  //     const newItem = { ...item };
  //     if (newItem.id === id) {
  //       if (isUp) newItem.value += 1;
  //       else newItem.value -= 1;
  //     }
  //     return newItem;
  //   });
  //   this.setState({ counters: newCounters });
  // }
  // }

  onChangeCounter = (id, role) => {
    if (role === 0) {
      const newCounters = this.state.counters.map((item) => {
        const newItem = { ...item };
        if (newItem.id === id) {
          // newItem.value = Number.parseInt(refs.valueref.value);
        }
        return newItem;
      });
      this.setState({ counters: newCounters });
    }
  }

  render() {
    return (
      <div>
        <div>
          <Counter
            id={0}
            role={1}
            value={10}
            onClickCounter={this.onClickCounter}
          />
        </div>
        <br />
        <div>
          {this.state.counters.map(item => (
            <Counter
              key={item.id}
              id={item.id}
              role={item.role}
              value={item.value}
              onClickCounter={this.onClickCounter}
            />
          ))}
        </div>
      </div>
    );
  }
}

// const Container1 = (numCounter) => {
//   const rows = [];
//   for (let i = 0; i < numCounter; i += 1) {
//     rows.push(<Counter />);
//   }
//   return (
//     <tbody>{rows}</tbody>
//   );
// };

export default Container1;

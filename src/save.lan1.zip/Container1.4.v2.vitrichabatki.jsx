import React, { Component } from "react";
import Counter from "./Counter";
import "./Container1.css";

const uuid = require("uuid");

class Container1 extends Component {
  constructor(props) {
    super(props);
    this.state = {
      counters: [
        { id: 0, value: 2, role: 0 },
        { id: 1, value: 6, role: 1 },
        { id: 2, value: 2, role: 0 },
        { id: 3, value: 2, role: 0 },
        { id: 4, value: 2, role: 0 },
        { id: 5, value: 2, role: 0 },
        { id: 6, value: 2, role: 0 },
      ],
    };
  }
  onClickCounter = (id, isUp, role) => {
    if (role === 0) {
      const newCounters = this.state.counters.map((item) => {
        const newItem = { ...item };
        if (newItem.id === id) {
          if (isUp) newItem.value += 1;
          else if (newItem.value !== 0) newItem.value -= 1;
        }
        return newItem;
      });
      this.setState({ counters: newCounters });
    } else {
      let newCounters = [...this.state.counters];
      const dadItem = newCounters.filter(item => (item.role === 1))[0];// thang cha
      // let dadItemIndex;// vi tri thang cha
      // for (let i = 0; i < newCounters.length; i += 1) {
      //   if (newCounters[i].role === 1) {
      //     dadItemIndex = i;
      //     break;
      //   }
      // }
      if (isUp) {
        dadItem.value += 1;
        // const a = this.state.counters.length;
        newCounters.push({ id: uuid(), value: 1, role: 0 });
      } else if (dadItem.value !== 0) {
        dadItem.value -= 1;
        const newCounterCopy = newCounters.filter((item) => {
          if (item.role === 0) return true;
          return false;
        });
        newCounterCopy.pop();
        // const dadCopy = newCounters.filter((item) => {
        //   if (item.role === 1) return true;
        //   return false;
        // });
        newCounterCopy.push(dadItem);
        newCounters = [...newCounterCopy];
        console.log(`${newCounters}`);
      }
      // newCounters[dadItemIndex].value = dadItem.value;
      this.setState({ counters: newCounters });
    }
  }
  onChangeCounter = (id, role, sNum) => {
    let newCounters = this.state.counters.map((item) => {
      const newItem = { ...item };
      if (newItem.id === id) {
        const temp = newItem.value;
        console.log(`temp: ${temp}`);
        const a = Number.parseInt(sNum, 10);
        console.log(`a: ${a}`);
        newItem.value = Number.isNaN(a) ? temp : a;
      }
      return newItem;
    });
    if (role === 1) {
      const a = this.state.counters.length - 1; // so Counter con
      const dadItem = newCounters.filter(item => item.role === 1)[0]; // thang cha
      const b = dadItem.value - a;
      console.log(`a-dad: ${a}`);
      console.log(`b-dad: ${b}`);
      if (b >= 0) {
        for (let i = 0; i < b; i += 1) {
          newCounters.push({ id: uuid(), value: 1, role: 0 });
          // a += 1;
          console.log(`i= ${i}`);
        }
      } else {
        const newCounterCopy = newCounters.filter((item) => {
          if (item.role === 0) return true;
          return false;
        });
        const dadCopy = newCounters.filter((item) => {
          if (item.role === 1) return true;
          return false;
        })[0];
        for (let i = b; i < 0; i += 1) {
          newCounterCopy.pop();
          console.log(`i= ${i}`);
        }
        newCounterCopy.push(dadCopy);
        newCounters = [...newCounterCopy];
        console.log(`${newCounters}`);
      }
    }
    this.setState({ counters: newCounters });
  }
  render() {
    const dad = this.state.counters.filter((item) => {
      if (item.role === 1) {
        return true;
      }
      return false;
    })[0];
    const child = this.state.counters.filter((item) => {
      if (item.role !== 1) {
        return true;
      }
      return false;
    });
    return (
      <div>
        <div className="dad">
          <Counter
            key={uuid()}
            id={dad.id}
            role={dad.role}
            value={dad.value}
            onClickCounter={this.onClickCounter}
            onChangeCounter={this.onChangeCounter}
          />
        </div>
        <div>
          {child.map(item => (
            <Counter
              key={uuid()}
              id={item.id}
              role={item.role}
              value={item.value}
              onClickCounter={this.onClickCounter}
              onChangeCounter={this.onChangeCounter}
            />
            ))}
        </div>
        <div />
      </div>
    );
  }
}
export default Container1;

import React from "react";
import PropTypes from "prop-types";

import "./Counter.css";

const Counter = props => (
  <div className="container">
    <input
      type="text"
      value={props.value}
      onChange={(e) => {
        // console.log(`e: ${e.target.value}`);
        props.onChangeCounter(props.id, props.role, e.target.value);
      }}
    />
    <div id="increase" className="btn">
      <button
        onClick={() => {
          props.onClickCounter(props.id, true, props.role);
        }}
      >
        +
      </button>
    </div>
    <div id="decrease" className="btn">
      <button
        onClick={() => {
          props.onClickCounter(props.id, false, props.role);
        }}
      >
        -
      </button>
    </div>
  </div>
);
Counter.propTypes = {
  id: PropTypes.string.isRequired,
  role: PropTypes.number.isRequired,
  value: PropTypes.number.isRequired,
  // refNum: PropTypes.number.isRequired,
  onClickCounter: PropTypes.func.isRequired,
  onChangeCounter: PropTypes.func.isRequired,
};


export default Counter;

